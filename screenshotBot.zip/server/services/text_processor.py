import re

from selenium.webdriver import ChromeOptions, Chrome

from .configs import ROOT_PATH

option = ChromeOptions()
option.headless = True
browser = Chrome(executable_path=f"{ROOT_PATH}server\\bin\\chromedriver.exe", options=option)
browser.get(f"{ROOT_PATH}server\\bin\\temp.html")


def translate_twemoji_emoji(buf: str) -> str:
    buffer = re.finditer(r"{\S+}", buf)
    res = []
    previous_end = 0
    current_end = 0
    for each in buffer:
        if each.span()[0] != previous_end:
            res.append(buf[previous_end: each.span()[0]])
        emoji_code = str(browser.execute_script("return twemoji.convert.fromCodePoint(arguments[0]);",
                                                buf[each.span()[0] + 1: each.span()[1] - 1]))
        res.append(emoji_code)
        current_end = each.span()[1]
    if current_end != len(buf):
        res.append(buf[current_end:])
    return "".join(res)


def process_multiple(block: str) -> dict:
    buffer = re.findall(r"((?P<index>#\d+ )(?P<content>\S+))", block)
    if len(buffer) == 0:
        return None
    else:
        # [('#1 测试2#234', '#1 ', '测试2#234'), ('#3 测试3', '#3 ', '测试3')]
        res = {}
        for each in buffer:
            res[each[1][1:].strip()] = each[2]
        res['max'] = int(max(res.keys()))
        return res


def process_single(block: str) -> dict:
    return {
        'max': 1,
        '1': block
    }