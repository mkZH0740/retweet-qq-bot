ROOT_PATH = "C:\\Users\\mike\\Documents\\GitHub\\vtb_retweet_bot\\"

DEFAULT_STYLE = "font-family=黑体;font-size=28px;color:black;"
