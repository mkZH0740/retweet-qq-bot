from nonebot.default_config import *

HOST = '127.0.0.1'
PORT = 12138
COMMAND_START = {'#'}
SUPERUSERS = {2267980149}
DEBUG = False